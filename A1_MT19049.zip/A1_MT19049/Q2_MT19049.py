# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 23:38:53 2020

@author: akanksha
"""

import nltk


from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import os

os.chdir("C:\\Users\\akanksha\\Desktop\\que2_folder\\")
import glob
foldername=glob.glob("./*")



def lower_case(s):
  input_str =s.lower()
  return input_str




def stemming(text):
    from nltk.stem import PorterStemmer 
    result=[]
    ps = PorterStemmer() 
    for w in text: 
        result.append(ps.stem(w)) 
    return result





def token(s):
  tokens = word_tokenize(s)
  return tokens




import string
def remove_punctuation(s):
  result = s.translate(str.maketrans(string.punctuation,"                                "))
  return result




from nltk.tokenize import TweetTokenizer 

def preprocessing(s):
  text=lower_case(s)
  text=remove_punctuation(text)
  text=token(text)
  text=stemming(text)
  return text

#positional index
positional_index={}

#foldername
count=0
total=0
for files in foldername:
    #read files
    print("files:",files)
    position=0
    file=glob.glob(files+"/*")
    print(type(file))
    for i in file:
    #list ko read karaa hai yha pe because text files pura list ke form hai\n",
        count=count+1
        #print(count) 
        f=open(i,'r',encoding='utf-8',errors="ignore")
        text=f.read()
        final_tokens=preprocessing(text)
        for i in final_tokens:
            position=position+1
            if i in positional_index.keys():
                if count in positional_index[i].keys():
                    positional_index[i][count].append(position)
                else:
                    positional_index[i][count]=[]
                    positional_index[i][count].append(position)
            else:
                positional_index[i]={}
                positional_index[i][count]=[position]            




                
#for anding of queris:
def query_And(new_doc_list):
    i=0
    j=0
    len1=len(new_doc_list[0])
    len2=len(new_doc_list[1])

    resultant=[]
    comparisions=0
    print("new_doc_list 0 ---",new_doc_list[0])
    print("new_doc_list 1---",new_doc_list[1])
    while(i<len1 and j<len2):
       comparisions=comparisions+1
       if(new_doc_list[0][i]==new_doc_list[1][j]):
        resultant.append(new_doc_list[0][i])
        i=i+1
        j=j+1
       elif(new_doc_list[0][i]<new_doc_list[1][j]):  
        i=i+1

       else:
        j=j+1
    print("resultant: ",resultant)
    print("resultant size: ",len(resultant))
    print("comparisions :",comparisions)
    return resultant
   
                
                
                
def query(que):
    flag=0
    tokens = que
    print(tokens)
    list_documents=[]
    for i in tokens:
      list_documents.append(list(positional_index[i].keys())) 
    #print("token",tokens)
    #print("list_documents",list_documents)
    length=len(list_documents)
    i=1
    result=list_documents[0]
    while(i<length):
        result=query_And([result,list_documents[i]])
        i=i+1
    #print("result:",result)
    docs=[]
    final=positional_index[tokens[0]][result[0]]
    for i in result:#decid loop
        #print("i ---",i)
        for j in range(len(tokens)-1):#token loop
           # print("j",tokens[j])
            
            flag=0
            x=final#1st token position
            y=positional_index[tokens[j+1]][i]#2nd token position
            #print("x:",x)
            #print("y",y)
            m=0
            n=0
            final1=[]
            while(m<len(x)):
                while(n<len(y)):
                    diff=x[m]-y[n]
                    if (diff==-1):
                        final1.append(x[n])
                    n=n+1
                m=m+1
            final=final1
            if(len(final)==0):
                flag=1
            
            #=j+1
        if(flag==1):
             docs.append(i)   
         
    #print("final",docs) 
    return len(docs)       
       
 
def initiate_the_phrasal_query():
      que =input ("Enter the query :") 
      x=""
     if len(que)==1:
          x=list(set(positional_index[que].keys()))
          print(x)
      else:
          que= preprocessing(que)
          x=query(que)  
        
      print("X documents :",x)
    
initiate_the_phrasal_query()

        
        
       
        
         

                